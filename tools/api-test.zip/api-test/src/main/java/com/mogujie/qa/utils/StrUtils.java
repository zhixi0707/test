package com.mogujie.qa.utils;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.http.Consts;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.CookieStore;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.AbstractHttpClient;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;


/**
 * http restful　请求封装，参数以对象形式传递　－－　用于场景测试
 * @author zhangcc
 *
 */
public class StrUtils {
	/**
	 * get request
	 * 
	 * @param url
	 * @param object
	 * @return
	 * @throws Exception
	 */
	public static CookieStore cookieStore = new BasicCookieStore();
	public static DefaultHttpClient client = new DefaultHttpClient();

	/**
	 * 返回String的 get请求
	 * 
	 * 
	 * */
	
	public static String httpStrGet(Object object, String url)
			throws Exception {

		String rUrl = "";
		HttpClient client = new DefaultHttpClient();
//		JSONObject json = new JSONObject();
		String str="";
		
		List<NameValuePair> nvps = new ArrayList<NameValuePair>();
		
		if (object == null) {
			rUrl = url;
		} else {
			nvps = gets(object);
			
			String param = URLEncodedUtils.format(nvps, Consts.UTF_8);
			
			rUrl = url + "?" + param;

		}
		System.out.println(rUrl);

		try {
			HttpGet httpget = new HttpGet(rUrl);
			HttpResponse httpResponse = client.execute(httpget);

			int responseCode = httpResponse.getStatusLine().getStatusCode();

			if (responseCode == 200) {
				HttpEntity entity = httpResponse.getEntity();

				if (entity != null) {
					str= EntityUtils.toString(entity);
				} else {
					System.out.println("http response is null");
				}
			} else {
				System.out.println("http GET request error, error code is "
						+ responseCode);
				// JSONObject errJson = new JSONObject();
//				json.put("status", responseCode);
				return str;
			}

			httpget.abort();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return str;
	}
	
	
	/**
	 * post request
	 * 
	 * @param url
	 * @param object
	 * @return
	 */
	public static String httpStrPost(Object object, String url) {

		HttpClient client = new DefaultHttpClient();

//		JSONObject json = new JSONObject();
		String str="";
		try {
			HttpPost httppost = new HttpPost(url);
			
			if (object != null) {
				List<NameValuePair> parameters = new ArrayList<NameValuePair>();

				parameters = getParamList(object);

				System.out.println(url);
				System.out.println(parameters);
				UrlEncodedFormEntity formEntiry = new UrlEncodedFormEntity(
						parameters, "UTF-8");
				httppost.setEntity(formEntiry);
			}

			HttpResponse response = client.execute(httppost);

			int responseCode = response.getStatusLine().getStatusCode();

			if (responseCode == 200) {
				HttpEntity entity = response.getEntity();

				if (entity != null) {
					
					str = EntityUtils.toString(entity);

				} else {
					System.out.println("entity is null");
				}
			} else {
				System.out.println(EntityUtils.toString(response.getEntity()));
				System.out
						.println("http POST request return error, error code is "
								+ responseCode);
			}
			httppost.abort();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return str;
	}

	/**
	 * httpdelete request
	 * 
	 * @param url
	 * @return
	 * @throws Exception
	 */
	public static String httpStrdelete(Object object,String url) throws Exception {
		URL url2;
		String str="";
		if(object != null){
		String params = get(object);
		url2 = new URL(url+"?"+params);
		} else {
			url2 = new URL(url);
		}
		HttpURLConnection urlConnection = (HttpURLConnection) url2
				.openConnection();
		urlConnection.setRequestMethod("DELETE");
		urlConnection.setDoOutput(true);
		urlConnection.setDoInput(true);

		InputStream in = urlConnection.getInputStream();
		BufferedReader bufferedReader = new BufferedReader(
				new InputStreamReader(in));
		StringBuffer temp = new StringBuffer();
		String line = bufferedReader.readLine();
		while (line != null) {
			temp.append(line).append(" ");
			line = bufferedReader.readLine();
		}
		System.out.println("httpdelete result " + temp.toString());
		str= temp.toString();
		
		return str;
	}
	/**
	 * httpput request
	 * 
	 * @param url
	 * @return
	 * @throws Exception
	 */
	public static String httpput(Object object, String url) throws Exception {
		String params = get(object);
		String str="";
		URL url2 = new URL(url + "?" + params);
//		logger.info(url2);
		System.out.println(url2);
		HttpURLConnection urlConnection = (HttpURLConnection) url2
				.openConnection();
		urlConnection.setRequestMethod("PUT");
		urlConnection.setDoOutput(true);
		urlConnection.setDoInput(true);

		InputStream in = urlConnection.getInputStream();
		BufferedReader bufferedReader = new BufferedReader(
				new InputStreamReader(in));
		StringBuffer temp = new StringBuffer();
		String line = bufferedReader.readLine();
		while (line != null) {
			temp.append(line).append(" ");
			line = bufferedReader.readLine();
		}
		str=temp.toString();
		return str;
	}

	public static String get(Object object) throws Exception {
		Class objClass = object.getClass();
		StringBuffer sb = new StringBuffer();
		while (objClass != null && !objClass.equals(Object.class)) {
			Field fields[] = objClass.getDeclaredFields();
			for (Field field : fields) {
				field.setAccessible(true);
				try {
					if (null == field.get(object)) {
						continue;
					}
				} catch (Exception e) {
					continue;
				}
				String value = "";
				value = field.get(object).toString();
				sb.append(field.getName() + "=" + value + "&");
			}
			objClass = objClass.getSuperclass();
		}
		String s = sb.toString();
		// System.out.println(s);
		s = s.substring(0, s.length() - 1);
		return s;
	}
	/**
	 * 为UTF-8编码添加
	 * @param object
	 * @return
	 * @throws Exception
	 */
	public static List<NameValuePair> gets(Object object) throws Exception {
		Class objClass = object.getClass();
		StringBuffer sb = new StringBuffer();
//		Map<String, String> map = new HashMap<String, String>();
		
		List<NameValuePair> nvps = new ArrayList<NameValuePair>();  
		
		while (objClass != null && !objClass.equals(Object.class)) {
			Field fields[] = objClass.getDeclaredFields();
			for (Field field : fields) {
				field.setAccessible(true);
				try {
					if (null == field.get(object)) {
						continue;
					}
				} catch (Exception e) {
					continue;
				}
				String value = "";
				value = field.get(object).toString();
//				sb.append(field.getName() + "=" + value + "&");
//				map.put(field.getName(), field.get(object).toString());
				nvps.add(new BasicNameValuePair(field.getName(), field.get(object).toString())); 
			}
			objClass = objClass.getSuperclass();
		}
//		String s = sb.toString();
//		// System.out.println(s);
//		s = s.substring(0, s.length() - 1);
//		return s;
		return nvps;
	}

	public static List<NameValuePair> getParamList(Object object)
			throws Exception {
		Class objClass = object.getClass();
		StringBuffer sb = new StringBuffer();

		List<NameValuePair> parameters = new ArrayList<NameValuePair>();

		while (objClass != null && !objClass.equals(Object.class)) {
			Field fields[] = objClass.getDeclaredFields();
			for (Field field : fields) {
				field.setAccessible(true);
				try {
					if (null == field.get(object)) {
						continue;
					}
				} catch (Exception e) {
					continue;
				}
				String value = "";
				value = field.get(object).toString();
				parameters.add(new BasicNameValuePair(field.getName(), value));
			}
			objClass = objClass.getSuperclass();
		}
		return parameters;
	}

	/**
	 * 随机返回用户名
	 * 
	 * @throws Exception
	 */
	public static String getRandomUserName() {
		long no = 999999999;
		long tmp = (long) (Math.random() * no);
		String phone = String.valueOf(tmp) + 12;
		System.out.println(phone);
		return String.valueOf(phone);
	}


	/**
	 * No request(JS)
	 * 封装个不需要请求的js静态接口方法
	 * 远程取得数据
	 * @param String urlString 数据远程路径
	 * @param String charset  数据编码
	 * @param int timeout 相应超时时间
	 * 
	 * */
	private static String getJSJSon(String urlString, final String charset,
			int timeout) throws IOException {
		if (urlString == null || urlString.length() == 0) {
			return null;
		}
		urlString = (urlString.startsWith("http://") || urlString
				.startsWith("https://")) ? urlString : ("http://" + urlString)
				.intern();
		URL url = new URL(urlString);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestProperty(
						"User-Agent",
						"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; Trident/4.0; .NET CLR 1.1.4322; .NET CLR 2.0.50727)");// 增加报头，模拟浏览器，防止屏蔽
		conn.setRequestProperty("Accept", "text/html");// 只接受text/html类型，当然也可以接受图片,pdf,*/*任意，就是tomcat/conf/web里面定义那些
		conn.setConnectTimeout(timeout);
		try {
			if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
				return null;
			}
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
		InputStream input = conn.getInputStream();
		BufferedReader reader = new BufferedReader(new InputStreamReader(input,
				charset));
		String line = null;
		StringBuffer sb = new StringBuffer();
		while ((line = reader.readLine()) != null) {
			sb.append(line);
		}
		if (reader != null) {
			reader.close();
		}
		if (conn != null) {
			conn.disconnect();
		}
		return sb.toString();

	}

	public static JSONObject getJSJSon(String urlString) throws IOException {
		return JSONObject.parseObject(getJSJSon(urlString, "utf-8", 5000));
		
	}	
	public static String getStrJS(String urlString) throws IOException {
		return  getJSJSon(urlString, "utf-8", 5000);
	
	}
	
	/**
	 * 获取cookie方法
	 * 
	 * */
	public static String getCookiesFromGet(String p, String url) {

		String rUrl = "";
		StringBuffer result = new StringBuffer();
		List<NameValuePair> nvps = new ArrayList<NameValuePair>();

		if (p == null || p.isEmpty()) {
			rUrl = url;
		} else {
			for (String s : p.split("&")) {
				if(s.split("=").length > 1){
				nvps.add(new BasicNameValuePair(s.split("=")[0],
						s.split("=")[1]));
				}
			}
			String param = URLEncodedUtils.format(nvps, Consts.UTF_8);

			rUrl = url + "?" + param;

		}
		try {

			HttpGet httpget = new HttpGet(rUrl);
			HttpResponse Response = client.execute(httpget);

			int httpResponse = Response.getStatusLine().getStatusCode();
			if (httpResponse == 200) {
				CookieStore cookieStore = ((AbstractHttpClient) client)
						.getCookieStore();
				List<Cookie> cookies = ((AbstractHttpClient) client)
						.getCookieStore().getCookies();
				for (Cookie c : cookies) {
					// System.out.println("cookie begin***\n" + c +
					// "\n cookie end");
					result.append(c.getName() + "=" + c.getValue() + "; ");
				}
				result.deleteCharAt(result.length() - 2);

			} else {
				System.out.println(EntityUtils.toString(Response.getEntity()));
				System.out
						.println("http POST request return error, error code is "
								+ httpResponse);
			}
			httpget.abort();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return result.toString();

	}
	/**get方法
	 * 封装需要cookie 进行调用的接口
	 * 适用于开始就需要登录页面
	 * */
	public static String httpSetgetCookie(Object object, String url,String cookie)
			throws Exception {
		String str="";
		String rUrl = "";
		HttpClient client = new DefaultHttpClient();
		JSONObject json = new JSONObject();
		
		List<NameValuePair> nvps = new ArrayList<NameValuePair>();
		
		if (object == null) {
			rUrl = url;
		} else {
			nvps = gets(object);
			
			String param = URLEncodedUtils.format(nvps, Consts.UTF_8);
			
			rUrl = url + "?" + param;

		}
		System.out.println(rUrl);

		try {

//			URL u = new URL(rUrl);
//			URI uri = new URI(u.getProtocol(), u.getHost(), u.getPath(), u.getQuery(),null);
			HttpGet httpget = new HttpGet(rUrl);
			if (cookie != null) {
				httpget.setHeader("Cookie", cookie);
			}
			HttpResponse httpResponse = client.execute(httpget);

			int responseCode = httpResponse.getStatusLine().getStatusCode();

			if (responseCode == 200) {
				HttpEntity entity = httpResponse.getEntity();

				if (entity != null) {
					str = EntityUtils.toString(entity);
				} else {
					System.out.println("http response is null");
				}
			} else {
				System.out.println("http GET request error, error code is "
						+ responseCode);
				// JSONObject errJson = new JSONObject();
				json.put("status", responseCode);
				return str;
			}

			httpget.abort();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return str;
	}
	/**post方法
	 * 封装需要cookie 进行调用的接口
	 * 适用于开始就需要登录页面
	 * */
	public static String httpSetpostCookie(Object object, String url,String cookie) {

		HttpClient client = new DefaultHttpClient();

		String str="";

		try {
			HttpPost httppost = new HttpPost(url);
			if(cookie!=null){
				httppost.setHeader("Cookie", cookie);
			}
			if (object != null) {
				List<NameValuePair> parameters = new ArrayList<NameValuePair>();

				parameters = getParamList(object);

				System.out.println(url);
				System.out.println(parameters);
				UrlEncodedFormEntity formEntiry = new UrlEncodedFormEntity(
						parameters, "UTF-8");
				httppost.setEntity(formEntiry);
			}

			HttpResponse response = client.execute(httppost);

			int responseCode = response.getStatusLine().getStatusCode();

			if (responseCode == 200) {
				HttpEntity entity = response.getEntity();

				if (entity != null) {
					
					str = EntityUtils.toString(entity);

				} else {
					System.out.println("entity is null");
				}
			} else {
				System.out.println(EntityUtils.toString(response.getEntity()));
				System.out
						.println("http POST request return error, error code is "
								+ responseCode);
			}
			httppost.abort();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return str;
	}
	
}

