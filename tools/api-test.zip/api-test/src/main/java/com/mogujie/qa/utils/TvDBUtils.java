package com.mogujie.qa.utils;
import java.sql.Connection;  
import java.sql.PreparedStatement;  
import java.sql.*;
import java.sql.DriverManager; 
public class TvDBUtils {
	public static final String url = "jdbc:mysql://103.15.202.86/tv?useUnicode=true&characterEncoding=UTF-8";  
    public static final String name = "com.mysql.jdbc.Driver";  
    public static final String user = "root";  
    public static final String password = "223238";  
  
    public static  Connection conn = null;  
    public static PreparedStatement pst = null;  
  
    public  TvDBUtils(String sql) {  
        try {  
            Class.forName(name);//指定连接类型  
            conn = DriverManager.getConnection(url, user, password);//获取连接  
            pst = conn.prepareStatement(sql);//准备执行语句  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
    }  
  
    public void close() {  
        try {  
            this.conn.close();  
            this.pst.close();  
        } catch (SQLException e) {  
            e.printStackTrace();  
        }  
    }  
}

