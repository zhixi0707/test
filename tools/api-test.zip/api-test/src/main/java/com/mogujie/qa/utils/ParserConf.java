package com.mogujie.qa.utils;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

/**
 * 读取配置文件
 * 
 * @author dulingling
 * 
 */
public class ParserConf {
	
	private Properties prop = new Properties();

	public ParserConf(String confFile) {
		try {
			File file = new File(confFile);
//			ClassLoader classLoader = getClass().getClassLoader();  
//		    File file = new File(classLoader.getResource(confFile).getFile());  
			InputStream in = new BufferedInputStream(new FileInputStream(file));
			prop.load(in);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	/**
	 * 返回string类型数据
	 * @param key
	 * @return
	 */
	public String getString(String key) {

		try {
			String ret = prop.getProperty(key);
			return ret;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 返回int类型数据
	 * @param key
	 * @return
	 */
	public int getIntValue(String key) {
		try {
			String ret = prop.getProperty(key);
			int rest = Integer.parseInt(ret);
			return rest;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	/**
	 * 返回long类型数据
	 */
	public long getLongValue(String key){
		try {
			String ret = prop.getProperty(key);
			long rest = Long.parseLong(ret);
			return rest;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}


}
