package com.mogujie.qa.utils;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

/**
 * http restful　请求封装，参数以string形式传递　－－　用于参数测试
 * @author zhangchengchun
 *
 */
public class Util {

	public static String sendRequet(String url, String requestMethod,
			String params) throws Exception {

		HttpURLConnection urlConnection = null;

		String ret = null;

		if (requestMethod.equalsIgnoreCase("get")) {
			String u = url + "?" + params;
			urlConnection = (HttpURLConnection) new URL(u).openConnection();
		} else {
			urlConnection = (HttpURLConnection) new URL(url).openConnection();
			urlConnection.setRequestMethod(requestMethod);
			if ("PUT".equalsIgnoreCase(requestMethod)) {
				urlConnection.addRequestProperty("Content-Type",
						"application/x-www-form-urlencoded");
			}

			urlConnection.setDoOutput(true);
			urlConnection.setDoInput(true);
			urlConnection.setUseCaches(false);

			urlConnection.setReadTimeout(20000);

			System.out.println(params);
			System.out.println(params.getBytes().length);

			if (params != "") {

				byte[] b = params.getBytes();
				// urlConnection.getOutputStream().write(b, 0, b.length);
				urlConnection.getOutputStream().write(b);
				urlConnection.getOutputStream().flush();
				urlConnection.getOutputStream().close();
			}

		}

		int code = urlConnection.getResponseCode();
		if (code == 200) {
			InputStream in = urlConnection.getInputStream();
			BufferedReader bufferedReader = new BufferedReader(
					new InputStreamReader(in));
			StringBuffer temp = new StringBuffer();
			String line = bufferedReader.readLine();
			while (line != null) {
				temp.append(line).append(" ");
				line = bufferedReader.readLine();
			}
			ret = temp.toString();
		} else {
			ret = "{\"status\":\"" + code + "\"}";
		}

		return ret;

	}

	/**
	 * http get request
	 * 
	 * @param url
	 * @param params
	 * @return
	 * @throws Exception
	 */
	public static JSONObject httpGet(String url, String params)
			throws Exception {
		String ret = sendRequet(url, "GET", params);
		JSONObject js = JSON.parseObject(ret);
		return js;
	}

	/**
	 * http post request
	 * 
	 * @param url
	 * @param params
	 * @return
	 * @throws Exception
	 */
	public static JSONObject httpPost(String url, String params)
			throws Exception {
		String ret = sendRequet(url, "POST", params);
		System.out.println(ret);
		JSONObject js = JSON.parseObject(ret);
		return js;
	}
	/**
	 * http put request
	 * 
	 * @param url
	 * @param params
	 * @return
	 * @throws Exception
	 */
	public static JSONObject httpPut(String url, String params)
			throws Exception {
		String ret = sendRequet(url, "PUT", params);
		JSONObject js = JSON.parseObject(ret);
		return js;
	}

	/**
	 * http delete request
	 * 
	 * @param url
	 * @param params
	 * @return
	 * @throws Exception
	 */
	public static JSONObject httpDelete(String url, String params)
			throws Exception {
		String ret = sendRequet(url, "DELETE", params);
		JSONObject js = JSON.parseObject(ret);
		return js;
	}
}
