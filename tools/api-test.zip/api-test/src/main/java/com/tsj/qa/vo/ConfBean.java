package com.tsj.qa.vo;

/**
 * 此类为读取配置 文件的bean文件
 * @author dulingling
 *
 */
public class ConfBean {

	public String caseFile;
	public int sheetNum;
	public int pathParamCount;
	
	public String getCaseFile() {
		return caseFile;
	}
	public void setCaseFile(String caseFile) {
		this.caseFile = caseFile;
	}
	public int getSheetNum() {
		return sheetNum;
	}
	public void setSheetNum(int sheetNum) {
		this.sheetNum = sheetNum;
	}
	public int getPathParamCount() {
		return pathParamCount;
	}
	public void setPathParamCount(int pathParamCount) {
		this.pathParamCount = pathParamCount;
	}

	
}
