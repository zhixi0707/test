package com.mogujie.qa.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import java.io.FileInputStream;

import java.io.InputStream;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import bsh.This;

public class ReadExcel {

	/**
	 * 返回数据类型 string[] 格式如下：v1|v2**p3=v3&p4=v4&p5=v5 v1 v2是path param,以 | 分隔,
	 * path_param_count=0表示无路径参数 p3=v3&p4=v4&p5=v5　为普通参数，形式已拼接成参数请求的形式
	 * path_param和普通参数以双星号"**"来分隔
	 * 	
	 * @param file
	 * @param sheetNum
	 */
	public static Object[][] readExcel(String filePath, int sheetNum,
			int path_param_count) {
        System.out.println(filePath);
		File file = new File(filePath);
		if (!file.exists()) {
			System.out.println("文件不存在");
			return null;
		}

		Object[][] objRet = null; // ROW: ret.len column: keys.len
		String[] keys = null; // store the params names
		String[] values = null; // store the params values
		String[] titleNames = null;// store titlenames values
		String[] ret = null; // store reuturn result

		try {
			// 从输入流创建workbook
			InputStream inputStream = new FileInputStream(file);
			String fileName = file.getName();
			Workbook wb = null;
			if (fileName.endsWith("xls")) {
				wb = new HSSFWorkbook(inputStream);// 解析xls格式
			} else if (fileName.endsWith("xlsx")) {
				wb = new XSSFWorkbook(inputStream);// 解析xlsx格式
			}
			Sheet sheet = wb.getSheetAt(sheetNum);// 获取第一个工作表
			int firstRowIndex = sheet.getFirstRowNum();
			int lastRowIndex = sheet.getLastRowNum();

			Row r = sheet.getRow(0);
			int cell_len = r.getLastCellNum();

			// 判断如果用例表格就一行，则直接返回空（第一行为表头）
			if (lastRowIndex > 0) {
				ret = new String[lastRowIndex];
			} else {
				System.out.println("无测试数据（为空，或只有一行）");
				return null;
			}

			if (cell_len > 1) {
				values = new String[cell_len - 1];
				keys = new String[cell_len - 1];
				objRet = new Object[lastRowIndex][5];
				titleNames = new String[cell_len - 1];
			} else {
				System.out.println("无测试数据（数据少于两列）");
				return null;
			}
			int k = 0; // key index -- col

			String str = null; // store for every finish string
			
			String titlename = ""; //保存注释变量

			for (int rIndex = firstRowIndex; rIndex <= lastRowIndex; rIndex++) {

				int m = 0; // value index
				int n = 0;
				Row row = sheet.getRow(rIndex);
				if (row != null) {
					int firstCellIndex = row.getFirstCellNum();
					int lastCellIndex = row.getLastCellNum();
					
					// firstCellIndex==0
					for (int cIndex = firstCellIndex; cIndex < lastCellIndex; cIndex++) {

						Cell cell = row.getCell(cIndex);

						String v = "";
						String value = "";
						if (cell != null) {
							v = cell.toString();
							value = v.trim();
//							titlename = v.trim();
							// System.out.print(value + "@\t");
							if (rIndex == 0 && cIndex > 0) { // cIndex>0就是丢弃了第一列
								keys[k] = value;
								k++;

							} else if (rIndex > 0 && cIndex > 0) {

								if (value != null) {
									if (value.equalsIgnoreCase("null")) {
										value = "NULL";
									}
									values[m] = value;
									m++;
								}
							} else if(rIndex > 0){
								titlename = value;
							}
//							else if (rIndex > 0 && cIndex == 0) {
//								titleNames[n] = titlename;
//								n++;
//							}
							
						}
					}
				}

				if (rIndex > 0) {
					Object[] o = spliceStr(titlename, keys, values,
							path_param_count);
					objRet[rIndex - 1] = o;
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return objRet;
	}

	/**
	 * 返回数据类型 string[] 格式如下：v1|v2**p3=v3&p4=v4&p5=v5 v1 v2是path param,以 | 分隔,
	 * path_param_count=0表示无路径参数 p3=v3&p4=v4&p5=v5　为普通参数，形式已拼接成参数请求的形式
	 * path_param和普通参数以双星号"**"来分隔
	 * 	
	 * @param file
	 * @param sheetNum
	 */
	public static Object[][] readExcel(String filePath, String sheetName,
			int path_param_count) {

		File file = new File(filePath);
		if (!file.exists()) {
			System.out.println("文件不存在");
			return null;
		}

		Object[][] objRet = null; // ROW: ret.len column: keys.len
		String[] keys = null; // store the params names
		String[] values = null; // store the params values
//		String[] titleNames = null;// store titlenames values
		String[] ret = null; // store reuturn result
		String titlename = "";

		try {
			// 从输入流创建workbook
			InputStream inputStream = new FileInputStream(file);
			String fileName = file.getName();
			Workbook wb = null;
			if (fileName.endsWith("xls")) {
				wb = new HSSFWorkbook(inputStream);// 解析xls格式
			} else if (fileName.endsWith("xlsx")) {
				wb = new XSSFWorkbook(inputStream);// 解析xlsx格式
			}
			Sheet sheet = wb.getSheet(sheetName);// 获取第一个工作表
			int firstRowIndex = sheet.getFirstRowNum();
			int lastRowIndex = sheet.getLastRowNum();

			Row r = sheet.getRow(0);
			int cell_len = r.getLastCellNum();

			// 判断如果用例表格就一行，则直接返回空（第一行为表头）
			if (lastRowIndex > 0) {
				ret = new String[lastRowIndex];
			} else {
				System.out.println("无测试数据（为空，或只有一行）");
				return null;
			}

			if (cell_len > 1) {
				values = new String[cell_len - 1];
				keys = new String[cell_len - 1];
				objRet = new Object[lastRowIndex][4];
//				titleNames = new String[cell_len - 1];
			} else {
				System.out.println("无测试数据（数据少于两列）");
				return null;
			}
			int k = 0; // key index -- col

			String str = null; // store for every finish string

			for (int rIndex = firstRowIndex; rIndex <= lastRowIndex; rIndex++) {

				int m = 0; // value index
				int n = 0;
				Row row = sheet.getRow(rIndex);
				if (row != null) {
					int firstCellIndex = row.getFirstCellNum();
					int lastCellIndex = row.getLastCellNum();

					for (int cIndex = firstCellIndex; cIndex < lastCellIndex; cIndex++) {

						Cell cell = row.getCell(cIndex);

						String v = "";
						String value = "";
						
						if (cell != null) {
							v = cell.toString();
							value = v.trim();
//							titlename = v.trim();
							// System.out.println("#####################");
							// System.out.print(value + "\t");
							// System.out.println("#####################");
							if (rIndex == 0 && cIndex > 0) { // cindex>0就是丢弃了第一列
								keys[k] = value;
								// System.out.println(value + "\t");
								k++;

							} else if (rIndex > 0 && cIndex > 0) {

								if (value != null) {
									if (value.equalsIgnoreCase("null")) {
										value = "NULL";
									}
									values[m] = value;
									m++;
								}
							} 
							else if (rIndex > 0 && cIndex == 0) {
//								titleNames[n] = titlename;
								titlename = value;
								n++;
							}
						}
					}
				}

				if (rIndex > 0) {
					Object[] o = spliceStr(titlename, keys, values,
							path_param_count);
					objRet[rIndex - 1] = o;
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return objRet;
	}

	// public static void main(String[] args) throws IOException {
	//
	// // String path = "C:/Users/dulingling/Desktop/case.xlsx";
	// //
	// // ReadExcel rt = new ReadExcel();
	// // rt.readExcel(path, 0, 1);
	//
	// String file = "params_set.xlsx";
	//
	// String path = ClassLoader.getSystemResource(file).getFile();
	// System.out.println(path);
	// ReadExcel rt = new ReadExcel();
	// rt.readExcel(path, 0, 1);
	// }

	/**
	 * 将从excel中读取到的数据，拼接成预期格式的字符串 path_param**params**check_field**expect_data
	 * 
	 * @param keys----> 第一行的属性名
	 * @param values  --> 后面的属性值
	 * @param path_param_count --> 路径参数
	 * @return
	 */
	public static Object[] spliceStr(String titleName, String[] keys,
			String[] values, int path_param_count) {
		
		int len = keys.length; //参数个数

		String path_params = "";
		String params = "";
		String check_field = "";
		String expect_data = "";
		String title = "";
		for (int i = 0; i < len; i++) { //遍历参数
			// 处理 path_params
			if (i < path_param_count) {
				path_params += values[i] + ","; // 只获取values值信息
			} else {// 再处理 普通参数
//				if (i < len - 2 && i > 0) {// 普通参数
				if (i < len - 2) {// 普通参数
					if (!(values[i].equalsIgnoreCase("null"))) { // 如果value不为null,则将k-v拼进参数变量中
						params += keys[i] + "=" + values[i] + "&";
					}
				} else if (i == len - 2) {
					check_field = values[i];
				} else if (i == len - 1) {
					expect_data = values[i];
				} 
//				else if (i == 0) {
//					title = titleNames[i];
//				}
			}
		}
		title = titleName;
		if (path_params != "") {
			path_params = path_params.substring(0, path_params.length() - 1);
		}

		if (params != "") {
			params = params.substring(0, params.length() - 1);
		}
		Object[] obj1 = new Object[] { title, path_params, params, check_field,
				expect_data };
		return obj1;
	}
}