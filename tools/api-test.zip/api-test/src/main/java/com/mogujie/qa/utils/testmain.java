package com.mogujie.qa.utils;

import org.springframework.util.SystemPropertyUtils;

public class testmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      System.out.println("asdasdad");
	}

}
