package com.mogujie.qa.utils;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.tsj.qa.vo.ConfBean;

public class ParamUtil {
	
	public static ConfBean getConf(String beanId) {
		ConfBean conf = null;

		ApplicationContext contex = new ClassPathXmlApplicationContext(
				"classpath:config.xml");

		conf = (ConfBean) contex.getBean(beanId);
		return conf;
	}
	
	public static Object[][] getExcelData(String beanId){
		ConfBean bean = ParamUtil.getConf(beanId);
		Object[][] params = ReadExcel.readExcel(bean.getCaseFile(), bean.getSheetNum(), bean.getPathParamCount());
		return params;
	}

}
